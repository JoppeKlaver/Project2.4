from api import *
from models import *


# Testing
@app.route('/test', methods=['GET'])
def test_get():
    user = User.query.first()
    user_schema = UserSchema()
    output = user_schema.dump(user).data
    return jsonify({'user': output})


# Custom jwt decorater
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = None

        if 'x-access-token' in request.headers:
            token = request.headers['x-access-token']

        if not token:
            return jsonify({'error': 'No token!'})

        try:
            data = jwt.decode(token, app.config['SECRET_KEY'])
            create_user = User.query.filter_by(
                public_id=data['public_id']).first()
        except:
            print(token)
            return jsonify({'error': 'Invalid token!'})

        return f(create_user, *args, **kwargs)

    return decorated


# CRUD Users
@app.route('/user', methods=['GET'])
@token_required
def get_all_users(create_user):
    if not create_user.admin:
        return jsonify({'error': 'Admin rights required'})

    users = User.query.all()

    output = []

    for user in users:
        user_data = {}
        user_data['public_id'] = user.public_id
        user_data['admin'] = user.admin
        user_data['username'] = user.username
        user_data['password'] = user.password
        output.append(user_data)

    return jsonify({'users': output})


@app.route('/user/<public_id>', methods=['GET'])
@token_required
def get_user(current_user, public_id):
    user = User.query.filter_by(public_id=public_id).first()

    if not user:
        return jsonify({'error': 'No user found'})

    user_data = {}
    user_data['public_id'] = user.public_id
    user_data['admin'] = user.admin
    user_data['username'] = user.username
    user_data['password'] = user.password

    return jsonify({'user': user_data})


@app.route('/user', methods=['POST'])
@token_required
def create_user(current_user):
    if not current_user.admin:
        return jsonify({'error': 'Admin rights required'})

    data = request.get_json()

    hash_password = generate_password_hash(data['password'], method='sha256')

    new_user = User(public_id=str(uuid.uuid4()),
                    username=data['username'], password=hash_password, admin=False)
    db.session.add(new_user)
    db.session.commit()

    return jsonify({'message': 'New user created'})


@app.route('/user/<public_id>', methods=['PUT'])
@token_required
def update_user(current_user, public_id):
    if not current_user.admin:
        return jsonify({'error': 'Admin rights required'})

    # To-do: Update and refactor this function to input nececary changes.
    user = User.query.filter_by(public_id=public_id).first()

    if not user:
        return jsonify({'error': 'No user found'})

    user.admin = True
    db.session.commit()

    return jsonify({'message': 'User has been changed'})


@app.route('/user/<public_id>', methods=['DELETE'])
@token_required
def delete_user(current_user, public_id):
    if not current_user.admin:
        return jsonify({'error': 'Admin rights required'})

    user = User.query.filter_by(public_id=public_id).first()

    if not user:
        return jsonify({'error': 'No user found'})

    db.session.delete(user)
    db.session.commit()

    return jsonify({'message': 'User has been deleted'})


# Login
@app.route('/login')
def login():
    auth = request.authorization

    if not auth or not auth.username or not auth.password:
        return make_response('Unable to verify', 401, {'WWW-Authenticate': 'Basic realm="Login required!"'})

    user = User.query.filter_by(username=auth.username).first()

    if not user:
        # return jsonify({'error' : 'User not found'})
        return make_response('Unable to verify', 401, {'WWW-Authenticate': 'Basic realm="Login required!"'})

    if check_password_hash(user.password, auth.password):
        token = jwt.encode({'public_id': user.public_id, 'exp': datetime.datetime.utcnow(
        ) + datetime.timedelta(minutes=42)}, app.config['SECRET_KEY'])

        return jsonify({'token': token.decode("UTF-8")})

    return make_response('Unable to verify', 401, {'WWW-Authenticate': 'Basic realm="Login required!"'})
