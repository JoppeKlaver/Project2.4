from flask import Flask, request, jsonify, make_response
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
import uuid
import datetime


app = Flask(__name__)

app.config.from_pyfile('config.py')

db = SQLAlchemy(app)
ma = Marshmallow(app)


# Even tho PEP8 doesn't like it this is neccecary.
# Altho this looks like circular imports it's not actually that bad since
# I'm not actually using anything from views in api or vice versa. This is
# a limitation from the language apparently(?).
from views import *


if __name__ == '__main__':
    app.run()
