# {
#     "admin": true,
#     "username": "User",
#     "password": "alpine12",
#     "details": [
#         {
#             "gender": "Male",
#             "insertion": null,
#             "last_name": "Gravenhorst",
#             "weight": 60,
#             "phone_number": "+31634347875",
#             "date_of_birth": "1989-07-27",
#             "e_mail_address": "k.t.c.gravenhorst@me.com",
#             "first_name": "Kyle",
#             "target_weight": 60,
#             "height": 175
#         }
#     ],
#     "address": [
#         {
#             "city": "Groningen",
#             "streetname": "Lunettenhof",
#             "zip_code": "9726KA",
#             "house_number": 56,
#             "house_number_addition": null
#         }
#     ]
# }

# {
#     "admin": false,
#     "username": "User",
#     "password": "alpine12",
#     "details": {
#         "gender": "Male",
#         "insertion": null,
#         "last_name": "Gravenhorst",
#         "weight": 60,
#         "phone_number": "+31634347875",
#         "date_of_birth": "1989-07-27",
#         "e_mail_address": "k.t.c.gravenhorst@me.com",
#         "first_name": "Kyle",
#         "target_weight": 60,
#         "height": 175
#     },
#     "address": {
#         "city": "Groningen",
#         "streetname": "Lunettenhof",
#         "zip_code": "9726KA",
#         "house_number": 56,
#         "house_number_addition": null
#     }
# }


{
    "instructions": [
        {
            "instruction": "Smeer de boter op één van beide boterhammen.",
            "step": 1
        },
        {
            "instruction": "Doe de sambal kaas op de besmeerde boterham.",
            "step": 2
        },
        {
            "instruction": "Bedek het geheel met de tweede boterham.",
            "step": 3
        }
    ],
    "dish": "Broodje sambal kaas",
    "calories": 132,
    "ingredients": [
        {
            "product": "Sambal kaas",
            "quantity": 20,
            "unit": "Gram"
        },
        {
            "product": "Brood",
            "quantity": 2,
            "unit": "Plakken"
        },
        {
            "product": "Boter",
            "quantity": null,
            "unit": null
        }
    ],
    "description": "Een dubbele bruine boterham met boter en sambal kaas"
}
