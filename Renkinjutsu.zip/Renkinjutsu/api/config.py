DEBUG = True

SECRET_KEY = 'philosophersstone'

SQLALCHEMY_DATABASE_URI = 'mysql://root:alpine12''@localhost/alchemy'
SQLALCHEMY_TRACK_MODIFICATIONS = False

# SWAGGER_UI_JSONEDITOR = True
